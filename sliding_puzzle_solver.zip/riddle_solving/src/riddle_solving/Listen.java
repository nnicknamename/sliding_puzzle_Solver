package riddle_solving;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Listen {
	JFrame frame;
	Listen(JFrame f){
		this.frame=f;
	}
	int [] selected= new int[8];
	ActionListener infoPopup() {
		ActionListener res=null;
		 res=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrame InfoFrame=new JFrame("Info");
					JTextPane pane=new JTextPane();
					pane.setText("Author: BlueCheez. \n"
							   + "Description: simple program to solve thi slider puzzle\n"
							   + "\n"
						   	   );
					pane.setBackground(InfoFrame.getBackground());

					pane.setEditable(false);
					InfoFrame.add(pane);
					InfoFrame.setSize(300, 130);  
					InfoFrame.setVisible(true);  
				}
			};
		return res;
	}
	ActionListener mix(Mecanics meca) {
		ActionListener res=null;
		 res=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					meca.mix();
				}
			};
			return res;
	}
		
	ActionListener solve(Mecanics meca,JButton b) {
		ActionListener res=null;
		 res=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 new BackgroundWorker(meca,b).start( );	
				/*	do {
						 meca.solve(); 
					   } while(meca.check()<8);*/
				}
			};
			return res;
	}

	ActionListener setupPopup(Mecanics meca) {
		ActionListener res=null;
		 res=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JFrame setupframe=new JFrame("setup");
					JPanel panel=new JPanel();
					String[] mat= {"0","1","2","3","4","5","6","7","8"};
					  int size=50;
					  int k=1;
						for(int i=0;i<3;i++) {
							for(int j=0;j<3;j++) {
								JComboBox box = new JComboBox(mat); 
								box.setSelectedIndex(k);
								box.setBounds(size*j,size*i,50, 30);    
								panel.add(box);
								if(k==8) {
									k=0;
								}else {
									k++;	
								}
							}
						}
					panel.setLayout(null);
			        JButton button_set = new JButton("set");
			        button_set.setBounds(50*4,10,100,100);
			        button_set.addActionListener(set(meca,panel,setupframe));
			        setupframe.add(button_set);
					setupframe.add(panel);
					setupframe.setSize(350, 200);  
					setupframe.setVisible(true);  
				}
			};
		return res;
	}
	ActionListener set(Mecanics meca,JPanel panel,JFrame frame) {
		ActionListener res=null;
	
		 res=new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int [][] mat=new int[3][3];
					for(int i=0;i<3;i++) {
						for(int j=0;j<3;j++) {
							mat[i][j]=(int) ((JComboBox)panel.getComponentAt(50*j,50*i)).getSelectedIndex();
						}	
					}
					meca.setTo(mat);
					frame.dispose();
				}
			};
			return res;
	}
}

