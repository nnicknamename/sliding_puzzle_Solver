package riddle_solving;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JToolBar;

class Frame extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Frame(String name){
		this.setResizable(false);
		BufferedImage img = null;
		try {
		    img = ImageIO.read(new File("rect163.png"));
		} catch (IOException e) {
			System.out.println("tnaket");
		}
		this.setIconImage(img);
		setTitle(name);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
		 Listen listen=new Listen(this);
	        Board board=new Board(this,listen);
	        JToolBar toolbar = new JToolBar();  
	        toolbar.setRollover(true);  
	        JButton button_info = new JButton("info");
	        button_info.setMnemonic('I');
	        JButton button_mix = new JButton("Mix");
	        button_mix.setMnemonic('m');
	        button_mix.addActionListener(listen.mix(board.getMecanics()));
	        JButton button_solve = new JButton("Solve");
	        button_solve .setMnemonic('s');
	        button_solve.addActionListener(listen.solve(board.getMecanics(),button_solve));
	        JButton button_manualSet = new JButton("Manual set");
	        button_manualSet .setMnemonic('a');
	        button_manualSet.addActionListener(listen.setupPopup(board.getMecanics()));
	        button_info.addActionListener(listen.infoPopup());
	        toolbar.add(button_info);  
	        toolbar.addSeparator();  
	        toolbar.add(button_mix); 
	        toolbar.addSeparator();  
	        toolbar.add(button_solve);  
	        toolbar.addSeparator();  
	        toolbar.add(button_manualSet);  
	        toolbar.addSeparator();  
	        Container contentPane = getContentPane();  
	        contentPane.add(toolbar, BorderLayout.NORTH);  
	        setSize(305, 365); 
	        setVisible(true); 
	}
	
}
