package riddle_solving;



public class Main {
	static int[][] rid=new int[3][3];
	public static void main(String[] args) {
		Frame frame =new Frame("Riddle Solver");
	}
	static void init() {
		int k=1;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(i==2 &&j==2) {
					rid[i][j]=0;
				}else {
					rid[i][j]=k;	
				}
				k++;
			}
		}
	}
}


