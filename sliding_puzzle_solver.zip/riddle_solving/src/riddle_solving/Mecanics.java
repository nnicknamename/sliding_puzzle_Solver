package riddle_solving;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JTextPane;
public class Mecanics {
	Board board;
	int[][] nums;
	int[][] w=new int[3][3];
	int p=1;
	boolean changed=false;
	boolean set=true;
	Mecanics(Board b){
		this.board=b;
	}

	void manage(int x,int y) {
	    nums=board.getBoard();
	    changed=false;
		if(legalMove(x,y)) {
			int[] pos= {x,y};
			move(pos);
		}
		if(changed) {
			board.setBoard(nums);
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	void move(int[]clickPosition){
		int[] zero=board.getZeroPosition();
		if(thereIsZeroInLine(clickPosition[0])) {
			if(zero[1]<clickPosition[1]) {
				manageVertical("left",zero,clickPosition);

			}else {
				manageVertical("right",zero,clickPosition);
			}
		}else {
			if(zero[0]<clickPosition[0]) {
				manageVertical("up",zero,clickPosition);
			}else {
				manageVertical("down",zero,clickPosition);

			}		}
	}
	void manageVertical(String direction,int[] zero,int[] clickPosition) {
		switch (direction) {
			case "down":
				for(int i=zero[0];i>clickPosition[0];i--) {
					nums[i][zero[1]]=nums[i-1][zero[1]];
				}
				break;
				
			case "up":
				for(int i=zero[0];i<clickPosition[0];i++) {
					nums[i][zero[1]]=nums[i+1][zero[1]];
				}
				break;
				
			case "right":
				for(int i=zero[1];i>clickPosition[1];i--) {
					nums[zero[0]][i]=nums[zero[0]][i-1];
				}
				break;
				
			case "left":
				for(int i=zero[1];i<clickPosition[1];i++) {
					nums[zero[0]][i]=nums[zero[0]][i+1];
				}
				break;
		}
			
			nums[clickPosition[0]][clickPosition[1]]=0;
	}
	boolean legalMove(int x,int y) {
		boolean res=false;
		if(thereIsZeroInLine(x)||thereIsZeroInColomn(y)) {
			res=true;
			changed=true;
		}
		return res;
	}
	boolean thereIsZeroInLine(int l){
		boolean res=false;
		for(int i=0;i<3;i++) {
			if(nums[l][i]==0) {
				res=true;
				i=3;
			}
		}
		return res;
	}
	boolean thereIsZeroInColomn(int C){
		boolean res=false;
		for(int i=0;i<3;i++) {
			if(nums[i][C]==0) {
				res=true;
				i=3;
			}
		}
		return res;
	}
	void mix() {
	    nums=board.getBoard();
	    int x,y;
	    Random rand=new Random();
		for(int i=0;i<100;i++) {
			changed=false;
			while(changed==false) {
				x=rand.nextInt(3);
				y=rand.nextInt(3);
				if(legalMove(x,y)) {
					int[] pos= {x,y};
					move(pos);
				}
			}
			
		}
		board.setBoard(nums);
	}
	void setTo(int[][] mat) {
		if(valid(mat)) {
			board.setBoard(mat);
		}else {
			JFrame frame=new JFrame("Error");
			JTextPane pane=new JTextPane();
			pane.setText("board not valid");
			pane.setEditable(false);
			pane.setBackground(frame.getBackground());
			frame.add(pane);
			frame.setSize(300, 50);  
			frame.setVisible(true);  
			System.out.println("board not valid");
		}
	}
	boolean valid(int[][] mat) {
		boolean res=true;
		int [] existed=new int[9];
		int k=0;
		start:
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				for(int l=0;l<k;l++) {
					if(mat[i][j]==existed[l]) {
						res=false;
						break start;
					}
				}
				existed[k]=mat[i][j];
				k++;
			}
		}
		return res;
	}
	void s() {
			manage(0,2);
			System.out.println("f");
	}
	void doIt() {
		 while(check()<8) {
			  solve(); 
		   }
	}
	void solve() {
	    nums=board.getBoard();
		  if (set) {  
		      if (nums[1][1]==0) {
		        theMiddleZero();
		      }
		      set=false;
		    }
		 System.out.println(check());
		    if (check()==0) {
		      middleOne();
		      rot_d();
		    } else {
		      if (check()==1) {
		        setTwo();
		        if (nums[0][1]!=2) {
		          rot_a();
		        }
		      } else {
		        if (check()==2) {
		          manage(1, 2);

		          if (nums[1][1]!=3 && nums[2][0]!=0) {
		            if (nums[0][2]==0) {
		              manage(0, 2);
		            }
		            rot_b();
		            if (nums[0][0]==1 && nums[0][1]==2 && nums[0][2]==0) {
		              manage(2, 2);
		              manage(2, 0);
		              manage(1, 0);
		            }
		          } else {
		            manage(2, 2);
		            manage(2, 0);
		            manage(1, 0);
		            manage(0, 0);
		            manage(0, 1);
		            manage(1, 1);
		            manage(1, 2);
		            manage(0, 2);
		            manage(0, 0);    
		            manage(1, 0);
		          }
		        } else {
		          if (check()==3) {
		            if (nums[1][0]!=4) {
		              rot_c();
		            }
		          } else {
		            if (check()==4) {
		              if (nums[2][0]==5) {
		                five();
		              } else {
		                rot_e();
		              }
		            } else {
		              if (check()==5) {
		                six();
		                while (nums[1][1]!=6) {
		                  rot_f();
		                }
		                manage(1, 0);
		                manage(2, 0);
		              }else{
		                if(check()==6){
		                  manage(2,2);
		                }
		              }
		            }
		          }
		        }
		      }
		    }
		  
		    //*******************************************************
		  }
	int check() {
		  int k=1, ctr=0;
		  for (int i=0; i<3; i++) {
		    for (int j=0; j<3; j++) {
		      if (nums[i][j]==k) {
		        ctr++;
		      } else {
		        j=3;
		        i=3;
		      }
		      k++;
		    }
		  }
		  return ctr;
		}
	void rot_d() {
		  //int p=1;
		  setting();
		  while (changed()==false) {
		    switch (p) {
		    case 1:
		      manage(0, 0);
		      break;
		    case 2:
		      manage(0, 2);
		      break;
		    case 3:
		      manage(2, 2);
		      break;
		    case 4:
		      manage(2, 0);
		      break;
		    }
		    if (p==4) {
		      p=1;
		    } else {
		      p++;
		    }
		  }
		  //delay(del);
		}
	boolean changed() {
		  boolean f=false;
		  int i, j, ctr=0;
		  for (i=0; i<3; i++) {
		    for (j=0; j<3; j++) {
		      if ( w[i][j]==nums[i][j]) {
		        ctr++;
		      }
		    }
		  }
		  if (ctr==9) {
		    f=false;
		  } else {
		    f=true;
		  }
		  return f;
		}
	void setting() {
		  int i, j;
		  for (i=0; i<3; i++) {
		    for (j=0; j<3; j++) {
		      w[i][j]=nums[i][j];
		    }
		  }
		}
	void middleOne() {
		  int p=1;
		  if (nums[1][1]==1) {
		    setting();
		    manage(1, 1);

		    if (changed()==false) {
		      while (changed()==false) {
		    	  System.out.println("f");
		        switch (p) {
		        case 1:
		          manage(0, 1);
		          break;
		        case 2:
		          manage(1, 2);
		          break;
		        case 3:
		          manage(2, 1);
		          break;
		        case 4:
		          manage(1, 0);
		          break;
		        }
		        if (p==4) {
		          p=1;
		        } else {
		          p++;
		        }
		        //delay(del);
		      }

		      manage(1, 1);

		      switch (p) {
		      case 1:
		        manage(2, 1);
		        break;
		      case 2:
		        manage(1, 0);
		        break;
		      case 3:
		        manage(0, 1);
		        break;
		      case 4:
		        manage(1, 2);
		        break;
		      }
		      //   delay(del);
		    } else {
		      theMiddleZero();
		    }
		  }
		}
	void theMiddleZero() {
		  if (num_find(1, 0)==1) {
		    if (num_find(1, 1)==0) {
		      manage(1, 2);
		    } else {
		      manage(1, 0);
		    }
		  } else {
		    if (num_find(1, 0)==0) {
		      manage(2, 1);
		    } else {
		      manage(0, 1);
		    }
		  }
		}
	int num_find(int n, int m ) { // "0" returns the i "else" returns j
		  int u=0, i, j;
		  for (i=0; i<3; i++) {
		    for (j=0; j<3; j++) {
		      if (nums[i][j]==n) {
		        if (m==0) {
		          u=i;
		        } else {
		          u=j;
		        }
		        i=3;
		        j=3;
		      }
		    }
		  }
		  return u;
		}
	void setTwo() {

		  int r=0;
		  if (num_find(2, 1)==0) { 
		    while (nums[num_find(2, 0)][1]!=0) { 
		      setting();
		      manage(r, 1);

		      if (r==2) {
		        r=0;
		      } else {
		        r++;
		      }
		      //rot_a();
		    }
		    setting();
		    manage(num_find(2, 0), 0);
		    if (nums[1][0]==0) {
		      setting();
		      manage(2, 0);
		      setting();
		      manage(2, 1);
		    } else {
		      setting();
		      manage(1, 0);
		      setting();
		      manage(1, 1);
		    }
		  }
		}
	void rot_c() { //a<=2
		  setting();
		  while (changed()==false) {
		    switch (p) {
		    case 1:
		      manage(1, 0);
		      break;
		    case 2:
		      manage(1, 2);
		      break;
		    case 3:
		      manage(2, 2);
		      break;
		    case 4:
		      manage(2, 0);
		      break;
		    }
		    if (p==4) {
		      p=1;
		    } else {
		      p++;
		    }
		  }
		}
	void rot_e() {
		  setting();
		  while (changed()==false) {
		    switch (p) {
		    case 1:
		      manage(2, 2);
		      break;
		    case 2:
		      manage(2, 1);
		      break;
		    case 3:
		      manage(1, 1);
		      break;
		    case 4:
		      manage(1, 2);
		      break;
		    }
		    if (p==4) {
		      p=1;
		    } else {
		      p++;
		    }
		  }
		}
	void rot_f() {
		  setting();
		  while (changed()==false) {
		    switch (p) {
		    case 1:
		      manage(1, 2);
		      break;
		    case 2:
		      manage(2, 2);
		      break;
		    case 3:
		      manage(2, 1);
		      break;
		    case 4:
		      manage(1, 1);
		      break;
		    }
		    if (p==4) {
		      p=1;
		    } else {
		      p++;
		    }
		  }
		}
		void five() {
		  manage(1, 1);
		  manage(1, 0);
		  manage(2, 0);
		  manage(2, 1);
		  manage(1, 1);
		  manage(1, 2);
		  manage(2, 2);
		  manage(2, 1);
		  manage(1, 1);
		  manage(1, 0);
		  manage(2, 0);
		  manage(2, 1);
		  manage(1, 1);
		  manage(1, 2);
		  manage(2, 2);
		  manage(2, 1);
		  manage(1, 1);
		  manage(1, 2);
		  manage(2, 2);
		  manage(2, 0);
		  manage(1, 0);
		  manage(1, 2);
		}
		void six() {
		  manage(2, 2);
		  manage(2, 0);
		  manage(1, 0);
		  manage(1, 1);
		}
		void rot_a() { 
			  setting();
			  while (changed()==false) {
			    //println(p);
			    switch (p) {
			    case 1:
			      manage(0, 1);
			      break;
			    case 2:
			      manage(0, 2);
			      break;
			    case 3:
			      manage(2, 2);
			      break;
			    case 4:
			      manage(2, 1);
			      break;
			    }
			    if (p==4) {
			      p=1;
			    } else {
			      p++;
			    }
			  }
			  //delay(del);
			}
			void rot_b() { //a<=2
			  if (nums[0][2]==0) {
			    manage(1, 2);
			  }
			  if (nums[1][0]==0) {
			    manage(1, 2);
			  } 
			  if (nums[1][2]==0) {
			    manage(2, 2);
			  } 
			  if (nums[2][2]==0) {
			    manage(2, 0);
			  } 
			  if (nums[2][0]==0) {
			    manage(1, 0);
			  }
			}
	}

