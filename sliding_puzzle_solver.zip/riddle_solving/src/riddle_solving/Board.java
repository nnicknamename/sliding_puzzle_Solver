package riddle_solving;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Board implements ActionListener{
	JFrame frame;
	Listen listen;
	JPanel panel;
    Mecanics meca=new Mecanics(this);
	int size=100;
	private int[][] board=new int[3][3];
	Board(JFrame f,Listen l){
		this.frame=f;
		this.listen=l;
		boardInitialize();
		initialize();
	}

	void initialize() {
		 panel=new JPanel();
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(board[i][j]!=0) {
					JButton button=new JButton(""+board[i][j]);
					button.setName(i+" "+j);
					button.setBounds(size*j,size*i,size, size);
					button.addActionListener(this);
					panel.add(button);
				}
			}	
		}
		panel.setLayout(null);
		frame.add(panel);
	}
	void setBoard(int[][] newBoard) {
			board=newBoard;
			frame.remove(panel);
			initialize();
			frame.revalidate();
			frame.repaint();
	}
	int[][] getBoard(){
		return board;
	}
	int[] getZeroPosition() {
		int[] res=new int[2];
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(board[i][j]==0) {
					res[0]=i;
					res[1]=j;
					i=3;
					j=3;
				}
			}
		}
		return res;
	}
	Mecanics getMecanics() {
		return meca;
	}
	void boardInitialize() {
		int k=1;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(i==2 &&j==2) {
					board[i][j]=0;
				}else {
					board[i][j]=k;	
				}
				k++;
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent n) {
		String data=((JButton)n.getSource()).getName();
		int[] num=new int[2];
		int k=0;
		for (String s : data.split("\\s"))  {
			num[k]=Integer.parseInt(s);
			k++;
		}
		meca.manage(num[0],num[1]);		
	}
}
