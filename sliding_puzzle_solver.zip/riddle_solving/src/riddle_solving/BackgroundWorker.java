package riddle_solving;

import javax.swing.JButton;
import javax.swing.SwingWorker;

public class BackgroundWorker extends SwingWorker<Object, Object> {
	Mecanics meca;
	JButton b;
	public BackgroundWorker(Mecanics meca,JButton b){
		this.meca=meca;
		this.b=b;
	}
	void start(){
		 b.setEnabled(false);
        execute();
	}

	@Override
	protected Object doInBackground() throws Exception {
		 meca.doIt();
		return null;
	}
	  @Override
      protected void done() {
			 b.setEnabled(true);
      }
}
